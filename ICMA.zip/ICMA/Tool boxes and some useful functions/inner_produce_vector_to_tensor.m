function s = inner_produce_vector_to_tensor(A,B)
[nb1,nb2,nb3] = size(B);
[nb, ~] = size(A);
nt = nb/(nb1*nb2*nb3);
s = zeros(1,nt);
for t = 1:nt
    s(1,t) = reshape(B,nb1*nb2*nb3,1)'*A((t-1)*nb1*nb2*nb3+1:t*nb1*nb2*nb3);
end
end