function t = uplus(t)
%UPLUS Unary plus (+) for tenmat.
%
%   See also TENMAT.
%
%Tensor Toolbox for MATLAB: <a href="https://www.tensortoolbox.org">www.tensortoolbox.org</a>



% This function does nothing!

