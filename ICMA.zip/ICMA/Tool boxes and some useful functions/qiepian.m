function s = qiepian(A)
[n1,n2,n3] = size(A);
%n = max(n1,n2,n3);
[x1,y1,z1] = meshgrid(1:n1,1:n2,1:n3);
s = slice(x1,y1,z1,A,[],[1:1:n2],[]);
%direction = [0 0 1];
%rotate(s,direction,90);
%direction = [0 1 0];
%rotate(s,direction,90);
axis([1 8 1 8 1 8]);
set(s,'linestyle','none');
set(gca,'xTick',[]);
set(gca,'yTick',[]);
set(gca,'zTick',[]);
alpha(0.7);
caxis([-0.1 1.1]);
