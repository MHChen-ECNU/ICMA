function beta_initial = get_beta_initial_via_hosvd(E_hat,omega_hat,r,p1,p2,p3)
n = size(omega_hat,2);
W = reshape(tensor(omega_hat' * tenmat(E_hat, 4)),[p1, p2, p3])/n;
beta_initial = hosvd(W,norm(W),'ranks',r,'sequential',true,'verbosity',0);
end