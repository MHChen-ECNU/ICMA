function s = produce_vector_to_tensor(A,B)
[nA1,nA2] = size(A);
[nB1,nB2,nB3,nB4] = size(B);
if nB4 == nA1 && nB4 ~=1
    s = zeros(nB1,nB2,nB3,nB4);
    for i = 1:nA1
        s(:,:,:,i) = B(:,:,:,i)*A(i,:);
    end
elseif nB4 == 1 && nA2 == 1
    s = zeros(nB1,nB2,nB3);
    for i = 1:nA1
        s(:,:,:,i) = B*A(i,:);
    end
elseif nB4 == 1 && nA1 == 1
    s = zeros(nB1,nB2,nB3);
    for i = 1:nA2
        s(:,:,:,i) = B*A(:,i);
    end
end
end