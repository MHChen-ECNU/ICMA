function s = inner_produce_tensor_to_tensor(A,B)
[~,~,~,na4] = size(A);
%[~,~,~] = size(B);
s = zeros(na4,1);
for i  = 1:na4
    s(i,1) = sum(sum(sum(A(:,:,:,i).*B)));
end
end