clear;
cd = 4;
open_file = "G:\1.Revisions for ICMA(code) in CSDA\Simulation_results\M_Simu_" + num2str(cd) + ".mat";
load(open_file);

p = zeros(rs,N^3);
TA = zeros(rs,N^3);
TB = zeros(rs,N^3);
h = ones(rs,N^3);
for j = 1:rs
for k = 1:N^3
    TA(j,k) = alpha_hat_rs(j,k)/std(alpha_rs_bs((j-1)*bs+1:j*bs,k),0);
    TB(j,k) = beta_hat_rs(j,k)/std(beta_rs_bs((j-1)*bs+1:j*bs,k),0);
    p(j,k) = max(2-2*normcdf(abs(TA(j,k))),2-2*normcdf(abs(TB(j,k))));
    if isnan(TA(k)) ||  isnan(TB(k))
        p(k) = 1;
    end
    %if std(alpha_zx((j-1)*bs+1:j*bs,k),0) == 0 || std(beta_zx((j-1)*bs+1:j*bs,k),0)
        %p(k) = 1;
    %end
    if p(j,k) > 0.05
        h(j,k) = 0;
    end 
end
    %[p(j,:),~,h(j,:)] = fdr_BH(p(j,:),0.05,false);
    %p(j,:) = mafdr(p(j,:),'BHFDR','T');
end
%h(p>0.05) = 0;
f = sum(h)/rs;
plot(1:512,f)
%axis([1 512 0 0.06])
axis([1 512 0 0.1])
%axis([1 512 0 1])
hold on
plot(1:512,0.05*ones(1,512))
set(gca,'FontSize',18)
%hold on
%plot(1:512,reshape(alpha,N^3,1)'.*reshape(beta,N^3,1)','m-')
%hold on
%plot(1:512,mean(alpha_hat_cf).*mean(beta_hat_cf))