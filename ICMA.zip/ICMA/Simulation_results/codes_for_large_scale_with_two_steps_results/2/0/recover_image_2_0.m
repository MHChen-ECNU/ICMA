p1 = 9; p2 = 12; p3 = 10;
IM = zeros(144,192,160);
IM((location_pm(ddr,1)-1)*p1 + 1:location_pm(ddr,1)*p1,(location_pm(ddr,2)-1)*p2 + 1:location_pm(ddr,2)*p2,(location_pm(ddr,3)-1)*p3 + 1:location_pm(ddr,3)*p3) = 1;
IM = make_nii(IM);
filename_PM = strcat('G:\1.Revisions for ICMA(code) in CSDA\Simulation_results\codes_for_large_scale_with_two_steps_results\2\0\image_',num2str(ddr),'_0.nii');
save_nii(IM,filename_PM)