library(Ball)
library(R.matlab)
setwd("G:/1.Revisions for ICMA(code) in CSDA/Simulation_results/codes_for_large_scale_with_two_steps_results/1/0")
a <- readMat('A_E_hat.mat')
A_E_hat <- a$A.E.hat
a <- readMat('epsilon_hat.mat')
epsilon_hat <- a$epsilon.hat
res <- bcov.test(A_E_hat,epsilon_hat)
p.value <- as.numeric(res$p.value)
writeMat('p_value_for_independent_test.mat',p_test_independent=p.value)
