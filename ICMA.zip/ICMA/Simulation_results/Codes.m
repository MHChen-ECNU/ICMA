%% Our simulations are based on matlab toolbox ``TensorReg Toolbox^{[1]}''.
% [1] Li, X., Xu, D., Zhou, H., & Li, L. (2018). Tucker tensor regression 
% and neuroimaging analysis. Statistics in Biosciences, 10, 520-545.
clear;
rng(0715);

%% Setting Part
% % Set the sizes of tensor varibales in this case less than [N_1,N_2,N_3] 
% or let these tensor varibales belong to \mathcal{R}^{N_1 \times N_2
% \times N_3}. icity, we allow N_1 = N_2 = N_3 = 8, and use N = 8 
% (different from N = N_1*N_2*N_3 in the paper)
N = 8;        

% % Assume that the Tucker Rank for tensor parameter \bm{\beta} is less
% than [r_1,r_2,r_3]. And use BIC to choose the best [r_1,r_2,r_3] from r.
% r is setting as follow. Here, we set r_i \in \{1,2,3\}, and by experience, 
% we found that only the change of the numerical order has little effect 
% on the value of BIC, so there are a total of ten candidate combinations in r.
r = [1 1 1;1 2 1;2 2 1;2 2 2];

% % Sample size = 100
n = 100;

% % Load the true values of image/tensor parameters
load('alpha.mat');
alpha = (alpha - min(min(min(alpha))))/(max(max(max(alpha))) - min(min(min(alpha))));
alpha(alpha<0.1) = 0;
load('beta.mat');
%beta = zeros(N,N,N); beta(alpha == 1) = 1;
psi = alpha;
delta = 10;
s = 10;

% % Consider five causal diagrams via c_1, c_2, c_3
cd = 3;   % This is optional

if cd == 1
    c1 = 0;
    c2 = 0;
    c3 = 1;
end
if cd == 2
    c1 = 1;
    c2 = 0;
    c3 = 1;
end
if cd == 3
    c1 = 0;
    c2 = 1;
    c3 = 0;
end
if cd == 4
    c1 = 1;
    c2 = 1;
    c3 = 0;
end
if cd == 5
    c1 = 1;
    c2 = 1;
    c3 = 1;
end

% % True values of parameters in different causal diagrams
alpha = c1*alpha;
beta = c2*beta;
delta = c3*delta;

%% Resampling to show the simulation performance
% % Resample times
rs = 500;

% % Bootstraping times
bs = 500;

alpha_hat_rs = zeros(rs,N^3);
beta_hat_rs = zeros(rs,N^3);
delta_hat_rs = zeros(rs,1);
%theta_hat_rs = zeros(rs,2);
alpha_rs_bs = zeros(rs*bs,N^3);
beta_rs_bs = zeros(rs*bs,N^3);
delta_rs_bs = zeros(rs*bs,1);
r_select = zeros(rs,3);

% % Start resampling
for dd=1:rs
    % % Produce observational data
    A_z = unifrnd(0,2,[n 1]);
    p_ = exp(0.5-0.5*A_z)./(1+exp(0.5-0.5*A_z));
    A_x = zeros(n,1);
    for i = 1:n
        A_x(i) = binornd(1,p_(i));
    end
    E = randn(N,N,N,n)*0.3;
    A_M = zeros(N,N,N,n);
    for i = 1:n
        A_M(:,:,:,i) = A_x(i)*alpha + A_z(i)*psi + E(:,:,:,i);
    end

    e = randn(n,1)*0.1;
    Y = zeros(n,1);
    for i = 1:n
        temp = reshape(A_M(:,:,:,i),N,N,N).*beta;
        Y(i,1) = delta*A_x(i) + sum(temp(:)) + s*A_z(i) + e(i);
    end
    clear temp

    % % Estimation
    A_XZ = [A_x,A_z];
    S_hat = zeros(size(A_XZ,2),N^3);
    E_hat = zeros(N,N,N,n);
    for j = 1:N^3
        qd1 = rem(j,N);
        qd1(qd1==0) = N;
        qd2 = rem((j-qd1)/N,N)+1;
        qd3 = ((j-qd1)/N-qd2+1)/N+1;
        temp = reshape(A_M(qd1,qd2,qd3,:),n,1);
        S_hat_ = (A_XZ'*A_XZ)\(A_XZ'*temp);
        E_hat(qd1,qd2,qd3,:) = temp - A_XZ*S_hat_;
        for r_xz = 1:size(A_XZ,2)
            S_hat(r_xz,j) = S_hat_(r_xz);
        end
    end
    clear temp
    alpha_hat_rs(dd,:) = S_hat(1,:);

    %theta_hat = (A_XZ'*A_XZ)\(A_XZ'*Y);
    %omega_hat = Y - A_XZ*theta_hat;

    % Choose [r_1 r_2 r_3] from set r via BIC
    omega_hat = Y - A_XZ*((A_XZ'*A_XZ)\(A_XZ'*Y));
    BIC = zeros(size(r,1),1);
    parfor rd = 1:size(r,1)
        [~,~,stat,~] = tucker_reg(A_XZ,A_M,Y,r(rd,:),'normal');
        stat = stat(end);
        stat = stat{1};
        BIC(rd) = stat.BIC;
    end
    rd = r(BIC == min(BIC),:);
    r_select(dd,:) = rd;
    r = 1;
    % % The following line of code replaces the default random beta initial value 
    % (which equals to ttensor(tenrand(r),arrayfun(@(j) 1-2*rand(p(j),r(j)), 1:d,'UniformOutput',false));
    % with the beta estimate obtained using HOSVD 
    % (which equals to hosvd(W,norm(W),'ranks',[r1,r2,r3],'sequential',true,'verbosity',0), 
    % and W = reshape(tensor(omega_hat' * tenmat(E_hat, 4)),[p1, p2, p3])/n,
    % n = size(omega_hat,2) ) to avoid the randomness of the parameter estimates 
    % caused by the randomness of the beta initial value when the \it{tucker_reg}
    % function is applied to regression.

    beta_intial = get_beta_initial_via_hosvd(E_hat,omega_hat,rd,N,N,N);
    %beta_intial = [];  % If the above line is work, please comment out this line

    if isempty(beta_intial)
        [gds_hat,beta_hat] = tucker_reg(A_XZ,A_M,Y,rd,'normal');
    else
        [gds_hat,beta_hat] = tucker_reg(A_XZ,A_M,Y,rd,'normal','B0',beta_intial);
    end
    beta_hat = double(beta_hat);
    beta_hat_rs(dd,:) = reshape(beta_hat,N^3,1)';
    delta_hat_rs(dd) = gds_hat(1);

    clearvars -except cd dd bs rs N n rd r A_M Y A_XZ E_hat beta_hat gds_hat alpha gamma1 beta gamma2 psi s delta alpha_hat_rs beta_hat_rs delta_hat_rs alpha_rs_bs beta_rs_bs delta_rs_bs r_select
    
    % % Inference
    alpha_bs_star = zeros(bs,N^3);
    beta_bs_star = zeros(bs,N^3);
    delta_bs_star = zeros(bs,1);
    epsilon_hat = Y - A_XZ*gds_hat - inner_produce_tensor_to_tensor(A_M,beta_hat);
    parfor ee = 1:bs
        v_star = binornd(1,0.5,n,1);
        v_star(v_star == 0) = -1;
        A_M_star = (A_M - E_hat) + produce_vector_to_tensor(v_star,E_hat);
        S_hat_star = zeros(size(A_XZ,2),N^3);
        E_hat_star = zeros(N,N,N,n);
        for bb = 1:N^3
            qd1 = rem(bb,N);
            qd1(qd1==0) = N;
            qd2 = rem((bb-qd1)/N,N) + 1;
            qd3 = ((bb-qd1)/N-qd2+1)/N + 1;
            temp = reshape(A_M_star(qd1,qd2,qd3,:),n,1);
            S_hat_ = (A_XZ'*A_XZ)\(A_XZ'*temp);
            E_hat_star(qd1,qd2,qd3,:) = temp - A_XZ*S_hat_;
            for r_xz = 1:size(A_XZ,2)
                S_hat_star(r_xz,bb) = S_hat_(r_xz);
            end
        end
        alpha_bs_star(ee,:) = S_hat_star(1,:);

        Y_star = A_XZ*gds_hat + inner_produce_tensor_to_tensor(A_M_star,beta_hat) + v_star.*epsilon_hat;
        %theta_hat_star = (A_XZ'*A_XZ)\(A_XZ'*Y_star);
        omega_hat_star = Y_star - A_XZ*((A_XZ'*A_XZ)\(A_XZ'*Y_star));

        beta_intial_star = get_beta_initial_via_hosvd(E_hat_star,omega_hat_star,rd+1,N,N,N);  % Here we slightly reduce the restriction on tucker rank (Luo, Y., & Zhang, A. R. (2022)).
        %beta_intial_star = []; % If the above line is work, please comment out this line

        if isempty(beta_intial_star)
            [gds_hat_star,beta_hat_star] = tucker_reg(A_XZ,A_M_star,Y_star,rd+1,'normal');
        else
            [gds_hat_star,beta_hat_star] = tucker_reg(A_XZ,A_M_star,Y_star,rd+1,'normal','B0',beta_intial_star);
        end
        beta_bs_star(ee,:) = reshape(double(beta_hat_star),N^3,1)';
        %delta_bs_star(ee,1) = theta_hat_star(1) - alpha_bs_star(ee,:)*beta_bs_star(ee,:)';
        delta_bs_star(ee,1) = gds_hat_star(1);
    end
    alpha_rs_bs((dd-1)*bs+1:dd*bs,:) = alpha_bs_star;
    beta_rs_bs((dd-1)*bs+1:dd*bs,:) = beta_bs_star;
    delta_rs_bs((dd-1)*bs+1:dd*bs) = delta_bs_star;
    disp(['The ',num2str(dd),'th resampling is ok.']);
end
clearvars -except cd bs rs N n r A_M Y A_XZ E_hat beta_hat gds_hat alpha gamma1 beta gamma2 psi s delta alpha_hat_rs beta_hat_rs delta_hat_rs alpha_rs_bs beta_rs_bs delta_rs_bs r_select
save_file = "G:\1.Revisions for ICMA(code) in CSDA\Simulation_results\H_Simu_" + num2str(cd) + ".mat";
save(save_file);