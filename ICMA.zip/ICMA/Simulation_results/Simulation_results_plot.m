clear
cd = 1;
open_file = "G:\1.Revisions for ICMA(code) in CSDA\Simulation_results\M_Simu_" + num2str(cd) + ".mat";
load(open_file);

%%
qiepian(reshape(mean(alpha_hat_rs),N,N,N));

%%
qiepian(reshape(mean(beta_hat_rs),N,N,N));

%%
qiepian(reshape(mean(alpha_hat_rs),N,N,N).*reshape(mean(beta_hat_rs),N,N,N));

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% alpha confidence interval %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
alpha_hat_ub = mean(alpha_hat_rs) + 1.96*std(alpha_hat_rs);
alpha_hat_lb = mean(alpha_hat_rs) - 1.96*std(alpha_hat_rs);
plot(1:N^3,alpha_hat_lb,'b:')
hold on
plot(1:N^3,alpha_hat_ub,'b:')
hold on
plot(1:N^3,mean(alpha_hat_rs),'r-')
axis([1 N^3 -0.5 0.5])
set(gca,'FontSize',18)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% beta confidence interval %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
beta_hat_ub = mean(beta_hat_rs) + 1.96*std(beta_hat_rs);
beta_hat_lb = mean(beta_hat_rs) - 1.96*std(beta_hat_rs);
plot(1:N^3,beta_hat_lb,'b:')
hold on
plot(1:N^3,beta_hat_ub,'b:')
hold on
plot(1:N^3,mean(beta_hat_rs),'r-')
axis([1 N^3 -0.2 1.2])
set(gca,'FontSize',18)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% alpha*beta confidence interval %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
ab_hat_rs = alpha_hat_rs.*beta_hat_rs;
ab_hat_ub = mean(ab_hat_rs) + 1.96*std(ab_hat_rs);
ab_hat_lb = mean(ab_hat_rs) - 1.96*std(ab_hat_rs);
plot(1:N^3, ab_hat_lb,'b:')
hold on
plot(1:N^3, ab_hat_ub,'b:')
hold on
plot(1:N^3,mean(ab_hat_rs),'r-')
axis([1 N^3 -0.5 0.5])
set(gca,'FontSize',18)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% delta confidence interval %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
delta_hat_ub = mean(delta_hat_rs) + 1.96*std(delta_hat_rs);
delta_hat_lb = mean(delta_hat_rs) - 1.96*std(delta_hat_rs);
save_file = "G:\1.Revisions for ICMA(code) in CSDA\Simulation_results\plots\M_Simu_" + num2str(cd) + "_d.mat";
save(save_file,'delta_hat_','delta_hat_lb','delta_hat_ub');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%