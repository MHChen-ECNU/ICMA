%% Our simulations are based on matlab toolbox ``TensorReg Toolbox^{[1]}''.
% [1] Li, X., Xu, D., Zhou, H., & Li, L. (2018). Tucker tensor regression 
% and neuroimaging analysis. Statistics in Biosciences, 10, 520-545.
clear;
rng(0715);

% Here is the additional Simulation
% Please replace "x x x x" in the address or the entire address with the appropriate one
%% Setting Part
% % Set the sizes of tensor varibales in this case less than [N_1,N_2,N_3] 
% or let these tensor varibales belong to \mathcal{R}^{N_1 \times N_2
% \times N_3}. icity, we allow N_1 = N_2 = N_3 = 8, and use N = 8 
% (different from N = N_1*N_2*N_3 in the paper)
%p1 = 9; p2 = 12; p3 = 10; Scale = 1;
%p1 = 16; p2 = 16; p3 = 16; Scale = 2;
p1 = 18; p2 = 24; p3 = 20; Scale = 3;
%p1 = 36; p2 = 48; p3 = 40; Scale = 4;
P1 = 144; P2 = 192; P3 = 160;

% % Sample size = 100
n = 100;

% % Load the true values of image/tensor parameters
load('alpha.mat');
alpha = (alpha - min(min(min(alpha))))/(max(max(max(alpha))) - min(min(min(alpha))));
alpha(alpha<0.1) = 0;
Alpha = zeros(P1,P2,P3);
Alpha(66:73,98:105,82:89) = 4*alpha;
%alpha_reduce = pool_mean(Alpha,p1,p2,p3);
load('beta.mat');
Beta = zeros(P1,P2,P3);
Beta(66:73,98:105,82:89) = beta;
%Beta(Alpha == 1) = 200;
%beta_hat = pool_mean(Beta,p1,p2,p3);
Psi = randn(P1,P2,P3);
delta = 10;
s = 10;

% % Consider five causal diagrams via c_1, c_2, c_3
cd = 5;

if cd == 1
    c1 = 0;
    c2 = 0;
    c3 = 1;
end
if cd == 2
    c1 = 1;
    c2 = 0;
    c3 = 1;
end
if cd == 3
    c1 = 0;
    c2 = 1;
    c3 = 0;
end
if cd == 4
    c1 = 1;
    c2 = 1;
    c3 = 0;
end
if cd == 5
    c1 = 1;
    c2 = 1;
    c3 = 1;
end

% % True values of parameters in different causal diagrams
Alpha = c1*Alpha;
Beta = c2*Beta;
delta = c3*delta;

%% Gerenate Simulation data
A_z = unifrnd(0,2,[n 1]);
p_ = exp(0.5-0.5*A_z)./(1+exp(0.5-0.5*A_z));
A_x = zeros(n,1);
for i = 1:n
    A_x(i) = binornd(1,p_(i));
end

M = zeros(P1,P2,P3,n);
for i = 1:n
    M(:,:,:,i) = A_x(i)*Alpha + A_z(i)*Psi;
end
E_reduce = randn(8,8,8,n)*0.2;
M(66:73,98:105,82:89,:) = M(66:73,98:105,82:89,:) + E_reduce;

e = randn(n,1)*0.1;
Y = zeros(n,1);
for i = 1:n
    temp = reshape(M(:,:,:,i),P1,P2,P3).*Beta;
    Y(i,1) = delta*A_x(i) + sum(temp(:)) + s*A_z(i) + e(i);
end

%% Step 1: Choose the potential region use $\bm\alpha_{reduce} \circ \bm\beta_{reduce}$
pool_method = 0; %if 1 pool_mean, 0 pool_max
M_reduce = zeros(p1,p2,p3,n);
for i = 1:n
    if pool_method == 1
        M_reduce(:,:,:,i) = pool_mean(reshape(M(:,:,:,i),P1,P2,P3),p1,p2,p3);
    elseif pool_method == 0
        M_reduce(:,:,:,i) = pool_max(reshape(M(:,:,:,i),P1,P2,P3),p1,p2,p3);
    end
end
% % Estimation
A_GX = [A_x,A_z];
S_hat = zeros(size(A_GX,2),p1*p2*p3);
E_hat = zeros(p1,p2,p3,n);
for j = 1:p1*p2*p3
    qd1 = rem(j,p1);
    qd1(qd1==0) = p1;
    qd2 = rem((j-qd1)/p1,p2)+1;
    qd3 = ((j-qd1)/p1-qd2+1)/p2+1;
    temp = reshape(M_reduce(qd1,qd2,qd3,:),n,1);
    S_hat_ = (A_GX'*A_GX)\(A_GX'*temp);
    E_hat(qd1,qd2,qd3,:) = temp - A_GX*S_hat_;
    for r_xz = 1:size(A_GX,2)
        S_hat(r_xz,j) = S_hat_(r_xz);
    end
end
alpha_hat = reshape(S_hat(1,:),p1,p2,p3);

% % Estimate of gamma_2, delta, beta and s_j 
% % Here, allowing the tucker decomposition of Beta is [B;U_1,U_2,U_3]
% % Suppose Tucker-rank(B) \in a given (experiential) set R, and use BIC to
% select appropriate size for core tensor B
% % Assume that the Tucker Rank for tensor parameter \bm{\beta} is less
% than [r_1,r_2,r_3]. And use BIC to choose the best [r_1,r_2,r_3] from r.
% r is setting as follow. Here, we set r_i \in \{1,2,3\}, and by experience, 
% we found that only the change of the numerical order has little effect 
% on the value of BIC, so there are a total of ten candidate combinations in r.
%load("R.mat");
%R = [1 1 1;1 2 1;1 3 1;2 2 1;3 2 1;3 3 1;2 2 2;2 2 3;3 3 2;3 3 3];
%R = [1 1 1];
R = [1 1 1;1 2 1;2 2 1;2 2 2;2 3 2;2 3 3;3 3 3];
BIC = zeros(size(R,1),1);
parfor r = 1:size(R,1)
    [~,~,stat,~] = tucker_reg(A_GX,M_reduce,Y,R(r,:),'normal');
    stat = stat(end);
    stat = stat{1};
    BIC(r) = stat.BIC;
end
r = R(BIC == min(BIC),:);

omega_hat = Y - A_GX*((A_GX'*A_GX)\(A_GX'*Y));

% % The following line of code replaces the default random beta initial value 
% (which equals to ttensor(tenrand(r),arrayfun(@(j) 1-2*rand(p(j),r(j)), 1:d,'UniformOutput',false));
% with the beta estimate obtained using HOSVD 
% (which equals to hosvd(W,norm(W),'ranks',[r1,r2,r3],'sequential',true,'verbosity',0), 
% and W = reshape(tensor(omega_hat' * tenmat(E_hat, 4)),[p1, p2, p3])/n,
% n = size(omega_hat,2) ) to avoid the randomness of the parameter estimates 
% caused by the randomness of the beta initial value when the \it{tucker_reg}
% function is applied to regression.
beta_intial = get_beta_initial_via_hosvd(E_hat,omega_hat,r,p1,p2,p3);
%beta_intial = [];  % If the above line is work, please comment out this line

if isempty(beta_intial)
    [gds_hat,beta_hat] = tucker_reg(A_GX,M_reduce,Y,r,'normal');
else
    [gds_hat,beta_hat] = tucker_reg(A_GX,M_reduce,Y,r,'normal','B0',beta_intial);
end
beta_hat = double(beta_hat);
delta_hat = gds_hat(1);

epsilon_hat = Y - A_GX*gds_hat - inner_produce_tensor_to_tensor(M_reduce,beta_hat);
bs = 500;
alpha_bs_star = zeros(bs,p1*p2*p3);
beta_bs_star = zeros(bs,p1*p2*p3);
delta_bs_star = zeros(bs,1);
parfor bb = 1:bs
    v_star = binornd(1,0.5,n,1);
    v_star(v_star == 0) = -1;
    M_reduce_star = (M_reduce - E_hat) + produce_vector_to_tensor(v_star,E_hat);
    S_hat_star = zeros(size(A_GX,2),p1*p2*p3);
    E_hat_star = zeros(p1,p2,p3,n);
    for j = 1:p1*p2*p3
        qd1 = rem(j,p1);
        qd1(qd1==0) = p1;
        qd2 = rem((j-qd1)/p1,p2)+1;
        qd3 = ((j-qd1)/p1-qd2+1)/p2+1;
        temp = reshape(M_reduce_star(qd1,qd2,qd3,:),n,1);
        S_hat_ = (A_GX'*A_GX)\(A_GX'*temp);
        E_hat_star(qd1,qd2,qd3,:) = temp - A_GX*S_hat_;
        for r_xz = 1:size(A_GX,2)
            S_hat_star(r_xz,j) = S_hat_(r_xz);
        end
    end
    alpha_bs_star(bb,:) = S_hat_star(1,:);
    
    Y_star = A_GX*gds_hat + inner_produce_tensor_to_tensor(M_reduce_star,beta_hat) + v_star.*epsilon_hat;
    
    omega_hat_star = Y_star - A_GX*((A_GX'*A_GX)\(A_GX'*Y_star));

    beta_intial_star = get_beta_initial_via_hosvd(E_hat_star,omega_hat_star,r+1,p1,p2,p3);
    %beta_intial_star = [];  % If the above line is work, please comment out this line

    if isempty(beta_intial_star)
        [gds_hat_star,beta_hat_star] = tucker_reg(A_GX,M_reduce_star,Y_star,r+1,'normal');
    else
        [gds_hat_star,beta_hat_star] = tucker_reg(A_GX,M_reduce_star,Y_star,r+1,'normal','B0',beta_intial_star);
    end
    beta_hat_star = double(beta_hat_star);
    beta_bs_star(bb,:) = reshape(beta_hat_star,p1*p2*p3,1)';
    delta_bs_star(bb) = gds_hat_star(1);
end

DE = delta_hat;T_DE = delta_hat/std(delta_bs_star);p_DE = 2-2*normcdf(abs(T_DE));

ab_sum_bs = sum(alpha_bs_star.*beta_bs_star,2); IE = inner_produce_tensor_to_tensor(alpha_hat,beta_hat);
T_IE = IE/std(ab_sum_bs); p_IE = 2-2*normcdf(abs(T_IE));

alpha_hat_vec = reshape(alpha_hat,p1*p2*p3,1)';
beta_hat_vec = reshape(beta_hat,p1*p2*p3,1)';
p = ones(p1*p2*p3,1);
TA = zeros(p1*p2*p3,1);
TB = zeros(p1*p2*p3,1);
for k = 1:p1*p2*p3
    TA(k) = alpha_hat_vec(k)/std(alpha_bs_star(1:bs,k),0);
    TB(k) = beta_hat_vec(k)/std(beta_bs_star(1:bs,k),0);
    p(k) = max(2-2*normcdf(abs(TA(k))),2-2*normcdf(abs(TB(k))));
    if isnan(TA(k)) ||  isnan(TB(k))
        p(k) = 1;
    end
end
%c_p = mafdr(p,'BHFDR','T');
c_p = p;                   
h = c_p <= 0.2;
%plot(1:p1*p2*p3,c_p)
%axis([1 p1*p2*p3 0 1])
%hold on
%plot(1:p1*p2*p3,0.2*ones(1,p1*p2*p3))

t = find(h == 1);
pm_num = length(t);
location_pm = zeros(length(t),3);
pd = rem(t,p1);
pd(rem(t,p1) == 0) = p1;
location_pm(:,1) = pd;
location_pm(:,2) = rem((t-location_pm(:,1))/p1,p2)+1;
location_pm(:,3) = ((t-location_pm(:,1))/p1-location_pm(:,2)+1)/p2+1;
disp(['The number of PM is ',num2str(pm_num)])

S_file_locus = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\PM_',num2str(Scale),'_',num2str(pool_method),'.mat');
save(S_file_locus,'location_pm','c_p','DE','p_DE','IE','p_IE');

H_test_epsilon = kstest(epsilon_hat/std(epsilon_hat));

%%%%%%%%%%%%%%%%
A_E_hat = zeros(n,p1*p2*p3);
for iii = 1:n
    A_E_hat(iii,:) = reshape(E_hat(:,:,:,iii),p1*p2*p3,1)';
end
S_E_file = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\A_E_hat.mat');
save(S_E_file,"A_E_hat",'-V6')
S_e_file = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\epsilon_hat.mat');
save(S_e_file,"epsilon_hat",'-V6')
Rpath = 'D:\Program Files\R\R-4.2.2\bin';                  %  the path for the installed 'R.exe'.  e.g.  Rpath = 'C:\Program Files\R\R-3.1.1\bin'
RscriptFileName = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\test_independent.R');
RunRcode(RscriptFileName,Rpath);
delete(S_E_file)
delete(S_e_file)
S_p_value_file = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\p_value_for_independent_test.mat');
load(S_p_value_file)

if H_test_epsilon || p_test_independent <= 0.05
    disp('The selection of first step does not match the assumptions!')
else
    disp('The selection of first step matches the assumptions!')
end
%%%%%%%%%%%%%%%%

clearvars -except location_pm pm_num A_GX M Y P1 P2 P3 p1 p2 p3 Scale pool_method
%% Step 2: Analyse potential mediation regions via ICMA method
n = size(Y,1);
p1 = P1/p1; p2 = P2/p2; p3 = P3/p3;
for ddr = 1:pm_num
    M_part = zeros(p1,p2,p3);
    for i = 1:n
        M_part(:,:,:,i) = M((location_pm(ddr,1)-1)*p1 + 1:location_pm(ddr,1)*p1,(location_pm(ddr,2)-1)*p2 + 1:location_pm(ddr,2)*p2,(location_pm(ddr,3)-1)*p3 + 1:location_pm(ddr,3)*p3,i);
    end
    % % Estimate of alpha, gamma_1 and psi_j
    S_hat = zeros(size(A_GX,2),p1*p2*p3);
    E_hat = zeros(p1,p2,p3,n);
    for j = 1:p1*p2*p3
        qd1 = rem(j,p1);
        qd1(qd1==0) = p1;
        qd2 = rem((j-qd1)/p1,p2)+1;
        qd3 = ((j-qd1)/p1-qd2+1)/p2+1;
        temp = reshape(M_part(qd1,qd2,qd3,:),n,1);
        S_hat_ = (A_GX'*A_GX)\(A_GX'*temp);
        E_hat(qd1,qd2,qd3,:) = temp - A_GX*S_hat_;
        for r_xz = 1:size(A_GX,2)
            S_hat(r_xz,j) = S_hat_(r_xz);
        end
    end
    alpha_hat = reshape(S_hat(1,:),p1,p2,p3);

    % % Estimate of gamma_2, delta, beta and s_j 
    % % Here, allowing the tucker decomposition of Beta is [B;U_1,U_2,U_3]
    % % Suppose Tucker-rank(B) \in a given (experiential) set R, and use BIC to
    % select appropriate size for core tensor B
    % % Assume that the Tucker Rank for tensor parameter \bm{\beta} is less
    % than [r_1,r_2,r_3]. And use BIC to choose the best [r_1,r_2,r_3] from r.
    % r is setting as follow. Here, we set r_i \in \{1,2,3\}, and by experience, 
    % we found that only the change of the numerical order has little effect 
    % on the value of BIC, so there are a total of ten candidate combinations in r.
    %load("R.mat");
    %R = [1 1 1;1 2 1;1 3 1;2 2 1;3 2 1;3 3 1;2 2 2;2 2 3;3 3 2;3 3 3];
    %R = [1 1 1];
    R = [1 1 1;1 2 1;2 2 1;2 2 2;2 3 2;2 3 3;3 3 3];
    BIC = zeros(size(R,1),1);
    parfor r = 1:size(R,1)
        [~,~,stat,~] = tucker_reg(A_GX,M_part,Y,R(r,:),'normal');
        stat = stat(end);
        stat = stat{1};
        BIC(r) = stat.BIC;
    end
    r = R(BIC == min(BIC),:);

    omega_hat = Y - A_GX*((A_GX'*A_GX)\(A_GX'*Y));

    % % The following line of code replaces the default random beta initial value 
    % (which equals to ttensor(tenrand(r),arrayfun(@(j) 1-2*rand(p(j),r(j)), 1:d,'UniformOutput',false));
    % with the beta estimate obtained using HOSVD 
    % (which equals to hosvd(W,norm(W),'ranks',[r1,r2,r3],'sequential',true,'verbosity',0), 
    % and W = reshape(tensor(omega_hat' * tenmat(E_hat, 4)),[p1, p2, p3])/n,
    % n = size(omega_hat,2) ) to avoid the randomness of the parameter estimates 
    % caused by the randomness of the beta initial value when the \it{tucker_reg}
    % function is applied to regression.
    beta_intial = get_beta_initial_via_hosvd(E_hat,omega_hat,r,p1,p2,p3);
    %beta_intial = [];  % If the above line is work, please comment out this line

    if isempty(beta_intial)
        [gds_hat,beta_hat] = tucker_reg(A_GX,M_part,Y,r,'normal');
    else
        [gds_hat,beta_hat] = tucker_reg(A_GX,M_part,Y,r,'normal','B0',beta_intial);
    end
    beta_hat = double(beta_hat);
    delta_hat = gds_hat(1); % Direct effect
    
    bs = 500; % The times of bootstraping
    epsilon_hat = Y - A_GX*gds_hat - inner_produce_tensor_to_tensor(M_part,beta_hat);
    alpha_bs = zeros(bs,p1*p2*p3);
    beta_bs = zeros(bs,p1*p2*p3);
    delta_bs = zeros(bs,1);
    parfor j = 1:bs
        rng(j*2023)
        v_star = binornd(1,0.5,n,1);
        v_star(v_star == 0) = -1;
        M_part_star = (M_part - E_hat) + produce_vector_to_tensor(v_star,E_hat);
        S_hat_star = zeros(size(A_GX,2),p1*p2*p3);
        E_hat_star = zeros(p1,p2,p3,n)
        for bb = 1:p1*p2*p3
            qd1 = rem(bb,p1);
            qd1(qd1==0) = p1;
            qd2 = rem((bb-qd1)/p1,p2)+1;
            qd3 = ((bb-qd1)/p1-qd2+1)/p2+1;
            temp = reshape(M_part_star(qd1,qd2,qd3,:),n,1);
            S_hat_ = (A_GX'*A_GX)\(A_GX'*temp);
            E_hat_star(qd1,qd2,qd3,:) = temp - A_GX*S_hat_;
            for r_xz = 1:size(A_GX,2)
                S_hat_star(r_xz,bb) = S_hat_(r_xz);
            end
        end
        alpha_bs(j,:) = S_hat_star(1,:);
    
        Y_star = A_GX*gds_hat + inner_produce_tensor_to_tensor(M_part_star,beta_hat) + v_star.*epsilon_hat;
    
        omega_hat_star = Y_star - A_GX*((A_GX'*A_GX)\(A_GX'*Y_star));

        beta_intial_star = get_beta_initial_via_hosvd(E_hat_star,omega_hat_star,r+1,p1,p2,p3);
        %beta_intial_star = [];  % If the above line is work, please comment out this line

        if isempty(beta_intial_star)
            [gds_hat_star,beta_hat_star] = tucker_reg(A_GX,M_part_star,Y_star,r+1,'normal');
        else
            [gds_hat_star,beta_hat_star] = tucker_reg(A_GX,M_part_star,Y_star,r+1,'normal','B0',beta_intial_star);
        end
        beta_hat_star = double(beta_hat_star);
        beta_bs(j,:) = reshape(beta_hat_star,p1*p2*p3,1)';
        delta_bs(j,1) = gds_hat_star(1);
    end
    
    alpha_hat_vec = reshape(alpha_hat,p1*p2*p3,1)';
    beta_hat_vec = reshape(beta_hat,p1*p2*p3,1)';
    p = ones(p1*p2*p3,1);
    TA = zeros(p1*p2*p3,1);
    TB = zeros(p1*p2*p3,1);
    for k = 1:p1*p2*p3
        TA(k) = alpha_hat_vec(k)/std(alpha_bs(1:bs,k),0);
        TB(k) = beta_hat_vec(k)/std(beta_bs(1:bs,k),0);
        p(k) = max(2-2*normcdf(abs(TA(k))),2-2*normcdf(abs(TB(k))));
        if isnan(TA(k)) ||  isnan(TB(k))
            p(k) = 1;
        end
    end
    c_p = mafdr(p,'BHFDR','T');
    %c_p = p;                    
    h = c_p <= 0.05;
   
    t = find(h == 1);
    qm_num = length(t);
    location_qm = zeros(length(t),3);
    qd = rem(t,p1);
    qd(rem(t,p1) == 0) = p1;
    location_qm(:,1) = qd;
    location_qm(:,2) = rem((t-location_qm(:,1))/p1,p2)+1;
    location_qm(:,3) = ((t-location_qm(:,1))/p1-location_qm(:,2)+1)/p2+1;
    if sum(h)>=1
        H_test_epsilon = kstest(epsilon_hat/std(epsilon_hat));
        figure(ddr);
        plot(1:p1*p2*p3,c_p)
        axis([1 p1*p2*p3 0 1])
        hold on
        plot(1:p1*p2*p3,0.05*ones(1,p1*p2*p3))
        hold off
        disp([num2str(ddr),'. The corresponding potential area of','(',num2str(location_pm(ddr,:)),')','is ok.'])
        disp('The specific site in this area is as follow')
        array2table(location_qm)
        disp(['The min p-value is ',num2str(min(c_p))])
        S_file = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\QM_',num2str(ddr),'_',num2str(Scale),'_',num2str(pool_method),'.mat');
        if H_test_epsilon
            disp('The error variable is not normal here.')
            p_test_independent = 0;
        else
            disp('Prefect! The error variable is normal here.')       % show the results of testing whether Y is normal or not via KS-test
            S_E_file = strcat('C:\Users\xxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\A_E_hat.mat');
            A_E_hat = zeros(n,p1*p2*p3);
            for ii = 1:n
                A_E_hat(ii,:) = reshape(E_hat(:,:,:,ii),p1*p2*p3,1)';
            end
            save(S_E_file,"A_E_hat",'-V6')
            S_e_file = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\epsilon_hat.mat');
            save(S_e_file,"epsilon_hat",'-V6')
            Rpath = 'D:\Program Files\R\R-4.2.2\bin';
            RscriptFileName = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\test_independent.R');
            RunRcode(RscriptFileName,Rpath);
            delete(S_E_file)
            delete(S_e_file)
            S_p_value_file = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\p_value_for_independent_test.mat');
            load(S_p_value_file)
            if p_test_independent >=0.05
                disp('Prefect!! The ICMA method is work in this area.')    % show the results of testing whether E is independent of e via Ball covariance
                [~,C] = kmeans(location_qm,1);
                %C = mean(location_qm);
                centre_pm = (location_pm(ddr,:)-1).*[p1,p2,p3] + C;
                disp(['Centre of these loci in the original image is ',num2str(centre_pm)])
            else
                disp('The ICMA method may be Unsuitable here.') 
            end
            delete(S_p_value_file)
        end
        save(S_file,'location_qm','location_pm','ddr','c_p','H_test_epsilon','p_test_independent')
    
        % % Direct effect
        DE = delta_hat;
        T_DE = delta_hat/std(delta_bs);
        p_DE = 2-2*normcdf(abs(T_DE));
        S_file_DE = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\DE_',num2str(ddr),'_',num2str(Scale),'_',num2str(pool_method),'.mat');
        save(S_file_DE,'DE','p_DE');
        
        % % Indirect effect
        ab_sum_bs = sum(alpha_bs.*beta_bs,2);
        ab_hat_sum = inner_produce_tensor_to_tensor(alpha_hat,beta_hat);
        IE = ab_hat_sum;
        T_IE = ab_hat_sum/std(ab_sum_bs);
        p_IE = 2-2*normcdf(abs(T_IE));
        S_file_IE = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\IE_',num2str(ddr),'_',num2str(Scale),'_',num2str(pool_method),'.mat');
        save(S_file_IE,'IE','p_IE');
    end
    if sum(h)==0
        disp([num2str(ddr),'. The corresponding potential area of','(',num2str(location_pm(ddr,:)),')', 'is false positive.'])
        if min(c_p) <= 0.1
            S_file = strcat('C:\Users\xxxx\Desktop\ICMA_chen\Simulation_results\codes_for_large_scale_with_two_steps_results\',num2str(Scale),'\',num2str(pool_method),'\PQM_',num2str(ddr),'_',num2str(Scale),'_',num2str(pool_method),'.mat');
            save(S_file,'ddr','c_p')
            disp(['The min p-value is',num2str(min(c_p))])
        end
    end
end
